package net.SuperAtraction.OpenCreators.sdk;

import java.io.*;
import java.util.jar.*;
import java.util.zip.ZipEntry;
import java.util.Enumeration;

public class Jar {

    public static void mkdirs (File file) throws IOException {
        if (!file.mkdirs()) {
            // Et on renvoit une exception en cas d'échec :
            throw new IOException("Unable to create directory : " + file);
        }
    }
	
	public static void EJar(String src, String dest) {
		// TODO Auto-generated method stub
		JarFile jarFile = null;
        try {
            jarFile = new JarFile(src);
            try {
                String jarName = jarFile.getName();
                String jarFolder = dest;
                System.out.println("Input = " + jarName);
                System.out.println("Output = " + jarFolder);
    
                // get the list of the jar file entries
                @SuppressWarnings("rawtypes")
				Enumeration enumeration = jarFile.entries();
                int i = 0;
                while (enumeration.hasMoreElements()) {
    
                    String elementName = enumeration.nextElement().toString();
    
                    // Pour chaque élément on récupère l'objet ZipEntry correspondant
                    ZipEntry entry = jarFile.getEntry(elementName);
    
                    // On crée également un File représentant le fichier et son répertoire parent :
                    File file = new File(jarFolder + File.separator + elementName);
                    
                    
                    if (entry.isDirectory()) {
                        // Si le répertoire n'existe pas on le crée :
                        if (!file.exists()) {
                            mkdirs(file);
                        }
                    } else {
                        File parent = file.getParentFile();
                        // Si le répertoire 'parent' n'existe pas on le crée :
                        if (!parent.exists()) {
                            mkdirs(parent);
                        }
        
                        i++;
                        System.out.println("Extraction de l'élément n°" + i + " : " + file);
                        
                        // On récupère l'InputStream du fichier à l'intérieur du ZIP/JAR
                        InputStream input = jarFile.getInputStream(entry);
                        try {
                            // On crée l'OutputStream vers la sortie :
                            OutputStream output = new FileOutputStream(file);
                            try {
                                // On utilise une lecture bufférisé :
                                byte[] buf = new byte[4096];
                                int len;
                                while ( (len=input.read(buf)) > 0 ) {
                                    output.write(buf, 0, len);
                                }
                            } finally {
                                // Fermeture du fichier de sortie
                                output.close();
                            }
                        } finally {
                            // Fermeture de kl'inputStream en entrée
                            input.close();
                        }
                    }
                } // fin while(enumeration)
            } finally {
                // Fermeture du JarFile
                jarFile.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
