package net.SuperAtraction.OpenCreators.sdk;

import java.awt.Desktop;
import java.io.*;

import javax.swing.*;

import net.SuperAtraction.OpenCreators.java.FileTools;
import net.SuperAtraction.OpenCreators.java.Url;
import net.SuperAtraction.OpenCreators.java.Zip;
import java.net.URISyntaxException;

public class Main {
	public static String appName = "d'un SDK";
	private static int oSI;
	private static String namePackage;
	private static BufferedReader br;
	
	@SuppressWarnings("resource")
	public static void update(int type, String[] args, int i, String program) {
		try
        {     
    		String Path = "";
    		if((args.length-i) >= 1)
    			Path=args[(i+1)];
          BufferedReader br = new BufferedReader(new FileReader(Path+"App.dat"));  
          StringBuffer sb = new StringBuffer();    
          String line, name="", Company="", Version="", lastest="", packagePath="", programPath="";
          for(int a=0;(line = br.readLine()) != null;a++)
          {
            // Ajoute la ligne au buffer
            sb.append(line);      
            sb.append("\n");     
            if(a==0) {name = line;
            }else if(a==1) {Company = line;
            }else if(a==2) {Version=line;
            }else if(a==3) {lastest=line;
            }else if(a==4) {packagePath=line;
            }else if(a==5) {programPath=line;
            }
          }  
          System.out.println("Caractéristiques: ");
          System.out.println(sb.toString());  
          Url.download(lastest, Path+"Version.dat");
          String olderL=lastest;
          lastest = (new BufferedReader(new FileReader(Path+"Version.dat"))).readLine();
          if(!Version.equals(lastest)) {
        	  JFrame frame = new JFrame();
        	  if(type==0)
        	  JOptionPane.showMessageDialog(frame,"Mise à jour de "+name+" "+Version+" à "+lastest+" depuis l'URL :\n"+packagePath+"\nVeillez patientez");
        	  Url.download(packagePath, Path+"package.dat");
        	  BufferedReader b = new BufferedReader(new FileReader(Path+"package.dat"));   
              String l;
              JFrame JF = new JFrame("Update of "+name);
              if(type==1)
            	  JF.setTitle("Installation de "+name);
              JF.setSize(350, 100);
              JLabel JL = new JLabel("Préparation...");
              JL.setBounds(1, 1, 350, 100);
              JF.add(JL);
              JF.setVisible(true);
              for(int c=0;(l = b.readLine()) != null;c++)
              {
				setNamePackage("");
				String path="", installP="", VersionNew="";
				for(int d=1;d<=3;d++) {
                	  if(d==1) {setNamePackage(l);
                	  }else if(d==2) {path=l;
                	  }else if(d==3) {installP=Path+l;
                	  }else if(d==4) {VersionNew=l;
                	  }l = b.readLine();
                  }
				if(type==0)
                  JL.setText("Recherche de mises à jours du package n°"+(c+1)+"...");
                  if(!Version.equals(VersionNew)) {
                	  if(type==0)
                	  JL.setText("Mise à jour du package n°"+(c+1)+"...");
                	  if(type==1)
                		  JL.setText("Installation du package n°"+(c+1)+"...");
                	  Url.download(path, Path+"package.zip");
                	  Zip.UnZip(Path+"package.zip", installP);
                  }
              }
              FileWriter fw = new FileWriter("App.dat");
              fw.write(name+"\n"+Company+"\n"+lastest+"\n"+olderL+"\n"+packagePath+"\n"+programPath);
              fw.close();
              File remove = new File(Path+"package.zip");
              remove.delete();
              remove = new File(Path+"package.dat");
              remove.delete();
              remove = new File(Path+"Version.dat");
              remove.delete();
              Launch(programPath);
          }else {
        	  System.out.println("Aucune Version Trouvée");
        	  File remove = new File(Path+"Version.dat");
              remove.delete();
          }
        }
        catch(IOException e)
        {
          e.printStackTrace();
        }
    	System.exit(0);
	}
	
	@SuppressWarnings({ "deprecation", "unused", "resource" })
	public static void main(String[] args) throws URISyntaxException, IOException {
		// TODO Auto-generated method stub
		int i=0;
		for (; i<args.length; i++)
		{
		    if ("-update".equals(args[i]))
		   {
		    	update(0, args, i, args[i+2]);
		   }else if("-install".equals(args[i])) {
			   update(1, args, i, "Get->App.dat");
		   }else if("-getUpdate".equals(args[i])) {
			 String Path = args[i+1];
			   BufferedReader br = new BufferedReader(new FileReader(Path+"App.dat"));  
		          StringBuffer sb = new StringBuffer();    
		          String line, name="", Company="", Version="", lastest="", packagePath="", programPath="";
		          for(int a=0;(line = br.readLine()) != null;a++)
		          {
		            // Ajoute la ligne au buffer
		            sb.append(line);      
		            sb.append("\n");     
		            if(a==0) {name = line;
		            }else if(a==1) {Company = line;
		            }else if(a==2) {Version=line;
		            }else if(a==3) {lastest=line;
		            }else if(a==4) {packagePath=line;
		            }else if(a==5) {programPath=line;
		            }
		          }  
		          System.out.println("Caractéristiques: ");
		          System.out.println(sb.toString());  
		          Url.download(lastest, Path+"Version.dat");
		          String olderL=lastest;
		          lastest = (new BufferedReader(new FileReader(Path+"Version.dat"))).readLine();
		          if(!Version.equals(lastest)) {
		        	  System.exit(1);
		          }else
		        	  System.exit(0);
		   	}	
		}
		
		File jar = new File(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
		String name = jar.getName();
		File app = new File("App.dat");
		System.out.println(i);
		if(name.equals("MaintenanceTool.jar") && app.exists() && args.length <= 1) {
			System.out.println("Démarrage du programme de maintenance...");
			
			br = new BufferedReader(new FileReader("App.dat"));  
			String line, nameApp="", Company="", Version="", lastest="";
	          for(int a=0;(line = br.readLine()) != null;a++)
	          {
	            if(a==0) {nameApp = line;
	            }else if(a==1) {Company = line;
	            }else if(a==2) {Version=line;
	            }else if(a==3) {lastest=line;
	            }
	          }   
			MaintenanceToolWindow w = new MaintenanceToolWindow(nameApp);
		}else {
		long init = System.currentTimeMillis();
		
		System.out.println(System.getProperty("user.home"));
		
		System.out.println("Vous utilisez "+System.getProperty("os.name"));
		String OS = System.getProperty("os.name");
		
		 String src = (new File(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getAbsolutePath());
		 String dest = "/tmp/SDKOpenCreatorsSystemJava/";
		 setoSI(0);
		    if(OS.toLowerCase().indexOf("nux") >= 0) {
			dest="/tmp/SDKOpenCreatorsSystemJava/";
			setoSI(1);
			System.out.println("LINUX");
		}else if(OS.toLowerCase().indexOf("win") >= 0) {
			dest="SDKJavaByOpenCreatorsInstallationFiles/";
			setoSI(2);
		}
		  System.out.println("Le SDK va decompresser son contenu dans "+dest);
		  long dep = System.currentTimeMillis();
		 Jar.EJar(src, dest);
		 
		 long end = System.currentTimeMillis();
		 System.out.println("\nTemps de décompression : "+(end - dep)+" millisecondes ("+((end - dep) / 1000)+" secondes)");
		 
		 dep = System.currentTimeMillis() - init;
		 System.out.println("Lancement de l'installation pour "+OS+" après "+dep+" millisecondes("+(dep / 1000)+" secondes) d'éxécution");
		 
		 FileTools.copy(dest+"App.dat", "App.dat");
		 BufferedReader br = new BufferedReader(new FileReader("App.dat"));  
         appName = br.readLine();
         br.close();
         File remove = new File("App.dat");
         remove.delete();
         String path = JOptionPane.showInputDialog("Chemin d'installation", System.getProperty("user.home")+"/"+appName);
		 
         File f = new File(path);
         f.mkdirs();
         FileTools.copy(dest+"App.dat", path+"/App.dat");
         FileTools.copy(new File(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getPath(), path+"/MaintenanceTool.jar");
		 Runtime runtime = Runtime.getRuntime();
		 runtime.exec("java -jar "+path+"/MaintenanceTool.jar -install "+path+"/");
		 System.out.println("java -jar "+path+"/MaintenanceTool.jar -install "+path);
		}
	}
	
	public static int Launch(String programPath) {
		System.out.println("Exec : "+programPath);
        File file = new File(programPath);
        if(!Desktop.isDesktopSupported())
        {
            System.out.println("not supported");
            return 0;
        }
        final Thread t1 = new Thread(){
            @Override
            public void run(){
          	  Desktop desktop = Desktop.getDesktop();
                System.out.println("Lancement de "+programPath+"...");
                try {
                if(file.exists()) {
                    desktop.open(file);
                }else
                	System.out.println("Java.io.FileNotFoundExeption : "+programPath);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            }
         };
         t1.start();
         return 0;
	}
	
	public static int getoSI() {
		return oSI;
	}
	public static void setoSI(int oSI) {
		Main.oSI = oSI;
	}
	public static String getNamePackage() {
		return namePackage;
	}
	public static void setNamePackage(String namePackage) {
		Main.namePackage = namePackage;
	}

}
