package net.SuperAtraction.OpenCreators.sdk;

import net.SuperAtraction.OpenCreators.java.FileTools;
import net.SuperAtraction.OpenCreators.java.Url;

public class Lib {

	public static void windows(String src) {
		// TODO Auto-generated method stub
		System.out.println();
		System.out.println("Téléchargement des librairies...");
		long dep = System.currentTimeMillis();
	    Url.download("https://ecologiccode.github.io/root/OpenCreators/SDK/QtLib.zip", src+"lib.zip");
	    long end = System.currentTimeMillis();
	    
	    System.out.println("Téléchargement des librairies Terminé en "+((end - dep) / 1000)+" secondes");
	    System.out.println();
	    dep = System.currentTimeMillis();
	    System.out.println("Installation des librairies...");
	    FileTools.UnZip(src+"lib.zip", src+"lib/");
	    
	    end = System.currentTimeMillis();
	    System.out.println("Installation des librairies Terminé en "+((end - dep) / 1000)+" secondes");
	    System.out.println();
	    System.out.println();
	    System.out.println("Traveaux d'installation de libs Terminé.");
	    System.out.println("Préparation à la phase suivante...");
	}
}
