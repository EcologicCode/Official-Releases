package net.SuperAtraction.OpenCreators.sdk.Linux;

import java.awt.Desktop;
import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;

import net.SuperAtraction.OpenCreators.java.FileTools;

public class Command {
	public static String appName = "SDK";
	
	@SuppressWarnings({ "deprecation" })
	public static boolean command(String cmd) {
		boolean ret = true;
		
		if(cmd.indexOf("external") >= 0) {
			Runtime runtime = Runtime.getRuntime();
			int i = 0;
			for (String s: cmd.split("-")) {
		         System.out.println(s);
		         i++;
		         if(i==2) {
		        	 try {
				runtime.exec("gnome-terminal -- bash -c "+s);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		         }
		      }
			
		}else if(cmd.indexOf("help") >= 0){
			try {  
			      BufferedReader br = new BufferedReader(new FileReader(new File("/tmp/SDKOpenCreatorsSystemJava/help.txt")));  
			      StringBuffer sb = new StringBuffer();    
			      String line;
			      while((line = br.readLine()) != null)
			      {
			        // ajoute la ligne au buffer
			        sb.append(line);      
			        sb.append("\n");     
			      }
			      System.out.println(sb.toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(cmd.indexOf("exit") >= 0){
			System.out.println("Sortie...");
			System.exit(0);
		}else {
			switch (cmd) { 
	        case "download-definitions code": 
	        	System.out.println("Souhaitez-vous télécharger les définitions de code ? [O/n]: ");
	        	if((new Scanner(System.in).next()).indexOf("O") >= 0) {
	        		Runtime runtime = Runtime.getRuntime();
	    			try {
	    				runtime.exec("gnome-terminal");
	    			} catch (IOException e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			}
	        		System.out.println("Pour cela, dans le terminal qui vient de s'ouvrir, insérez la commande suivante: \"sudo apt install qtcreator\"");
	        	}else {
	        		System.out.println("D'accord");
	        	}
	            break; 
	        case "install":
	        	System.out.println("Système s'installation.\nFournisez le chemin d'installation, ou \"0\" si vous le souhaitez à l'emplacement d'installation(/home/"+System.getProperty("user.name")+"/"+appName+"/)");
	        	String path = (new Scanner(System.in)).nextLine();
	        	if(path.indexOf("0") >= 0) {
	        		path = "/home/"+System.getProperty("user.name")+"/"+appName;
	        	}
	        	System.out.println("Nous allons installer "+appName+" dans "+path+"...");
	        	
	        	FileTools.copyDir("/tmp/SDKOpenCreatorsSystemJava/", path+"/");
	            
	            File dossier = new File(path+"/program/"); 
	            dossier.mkdir();
	            
	        	
	        	FileTools.copyDir("/tmp/SDKOpenCreatorsSystemJava/Linux/", path+"/program/");
	        	System.out.println("Initialisation de java en mode zero...");
	        	Runtime runtime = Runtime.getRuntime();
    			try {
    				runtime.exec("gnome-terminal -- bash /C java -zero");
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    			System.out.println("Java a été initialisé en mode Zero...");
    			try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    			System.out.println("Démarrage de l'UI...");
    			try {
    				runtime.exec(path+"/pogram/installer.jar");
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
	        	break;
	        case "web" :
	        	System.out.print("Service Web : entrez le nom du site Web ou \"SDK\" pour ouvrir la page officielle :");
	        	String web = (new Scanner(System.in)).nextLine();
	        	
	        	if(web.indexOf("SDK") >= 0) {
	        		web = "https://Ecologiccode.github.io/OpenCreators/tools/deploy/SDK.jar/";
	        	}
	        	try {
					Desktop.getDesktop().browse(new URL(web).toURI());
				} catch (IOException | URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	break;
	        default : 
	        	System.out.println("La commande \""+cmd+"\" n'a pas été trouvée\nEssayez \"external "+cmd+"\" (Uniquement pour Ubuntu Gnome).");
	            break; 
	        } 
		}
		
		return ret;
	}
}
