/**
 * 
 */
package net.SuperAtraction.OpenCreators.sdk;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * @author superatraction
 *
 */
public class MaintenanceToolWindow extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MaintenanceToolWindow(String name) {
		//Donner un titre à la fenêtre
        this.setTitle("Outil de Maintenance pour "+name);
         
        //On veut que la fenetre s'ouvre au centre de la page
        this.setLocationRelativeTo(null);
         
        //On choisi la taille de la fenetre
        this.setSize(400, 400);
        
        this.setResizable(false);
        
        JLabel intro = new JLabel("Bienvenue sur ce programme de Maintenance !", JLabel.CENTER);
        intro.setBounds(0, 190, 400, 30);
        JButton Cancel = new JButton("Annuler");
        Cancel.setBounds(0, 0, 100, 20);
        Cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
        JButton Next = new JButton("Suivant");
        Next.setBounds(300, 0, 100, 20);
        Next.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
        this.add(Next);
        this.add(intro);
        this.add(Cancel);
         
        //On ferme les programmes quand on clique sur la croix rouge
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        this.setLayout(null);
         
        //On rend la fenêtre visible
        this.setVisible(true);
	}

}
