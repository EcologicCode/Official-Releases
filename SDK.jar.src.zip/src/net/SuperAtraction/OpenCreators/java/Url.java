package net.SuperAtraction.OpenCreators.java;

import java.io.*;
import java.net.URL;

public class Url {
	public static void download(String URL, String dest) {
		try (BufferedInputStream bis = new BufferedInputStream(new URL(URL).openStream());  
				  FileOutputStream fos = new FileOutputStream(dest)) {
				    byte data[] = new byte[1024];
				    int byteContent;
				    while ((byteContent = bis.read(data, 0, 1024)) != -1) {
				        fos.write(data, 0, byteContent);
				    }
				} catch (IOException e) {
				   e.printStackTrace(System.out);
				}
	}
}
