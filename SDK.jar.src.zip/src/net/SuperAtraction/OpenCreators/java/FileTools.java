package net.SuperAtraction.OpenCreators.java;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class FileTools {
	public static void UnZip(String FILE_PATH, String OUTPUT_FOLDER) {
		// Créez le dossier Output s'il n'existe pas.
		File folder = new File(OUTPUT_FOLDER);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		// Créez un buffer (Tampon).
		byte[] buffer = new byte[1024];

		ZipInputStream zipIs = null;
		try {
			// Créez un objet ZipInputStream pour lire les fichiers à partir d'un chemin (path).
			zipIs = new ZipInputStream(new FileInputStream(FILE_PATH));

			ZipEntry entry = null;
			// Parcourir chaque Entry (de haut en bas jusqu'à la fin)
			while ((entry = zipIs.getNextEntry()) != null) {
				String entryName = entry.getName();
				String outFileName = OUTPUT_FOLDER + File.separator + entryName;
				System.out.println(outFileName);

				if (entry.isDirectory()) {
					// Créer des dossiers.
					new File(outFileName).mkdirs();
				} else {
					// Créez un Stream pour graver des données dans le fichier.
					FileOutputStream fos = new FileOutputStream(outFileName);

					int len;
					// ​​​​​​​
					// Lisez les données sur Entry présent
					while ((len = zipIs.read(buffer)) > 0) {
						fos.write(buffer, 0, len);
					} 
					fos.close();
				} 
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				zipIs.close();
			} catch (Exception e) {
			}
		}
	}
	
	public static void copy(String srcs, String dests) {
		System.out.println("Copie de "+srcs+" à "+dests);
		File src = new File(srcs); 
		
	    File dest = new File(dests);
	    if(src.isDirectory()) {
			dest.mkdir();
			return;
		}
	    InputStream is = null;
	    OutputStream os = null;
	  
	    try {
	        is = new FileInputStream(src);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int len;
	        while ((len = is.read(buffer)) > 0) {
	            os.write(buffer, 0, len);
	        }
	        is.close();
	        os.close();
	    }
	    catch(IOException e){
	        e.printStackTrace();
	    }
	}
	
	public static void copyDir(String src, String dest) {
		File dir  = new File(src);
		File dirDest = new File(dest);
		dirDest.mkdirs();
	      File[] liste = dir.listFiles();
	      for(File item : liste){
	        copy(src+item.getName(), dest+item.getName());
	      }
	}
}
